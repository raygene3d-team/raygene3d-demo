
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl15/types.h>
#include <glbinding/gl15/boolean.h>
#include <glbinding/gl15/values.h>
#include <glbinding/gl15/bitfield.h>
#include <glbinding/gl15/enum.h>
#include <glbinding/gl15/functions.h>
